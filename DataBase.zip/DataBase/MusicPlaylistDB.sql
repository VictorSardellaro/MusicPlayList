CREATE DATABASE [MusicPlaylist]
GO

USE [MusicPlaylist]
GO

CREATE TABLE [Author]
(
    [Id] INT IDENTITY(1,1) NOT NULL,
    [Name] NVARCHAR(80) NOT NULL,    
    CONSTRAINT [PK_Author] PRIMARY KEY ([Id])
);
GO

CREATE TABLE [Genre]
(
    [Id] INT IDENTITY(1,1) NOT NULL,
    [Name] NVARCHAR(80) NOT NULL,    
    CONSTRAINT [PK_Genre] PRIMARY KEY ([Id])
);
GO

CREATE TABLE [Playlist]
(
    [Id] INT IDENTITY(1,1) NOT NULL,    
    [PlaylistTitle] NVARCHAR(160) NOT NULL,    
    CONSTRAINT [PK_Playlist] PRIMARY KEY ([Id])
    
);
GO

CREATE TABLE [Music]
(
    [Id] INT IDENTITY(1,1) NOT NULL,
    [MusicTitle] NVARCHAR(160) NOT NULL,    
    [MusicDuration] TIME NOT NULL, 
    [AuthorId] INT NOT NULL,
    [GenreId] INT NOT NULL,
    CONSTRAINT [PK_Music] PRIMARY KEY ([Id]),
	CONSTRAINT [FK_Author] FOREIGN KEY ([AuthorId]) REFERENCES [Author] ([Id]),
	CONSTRAINT [FK_Genre] FOREIGN KEY ([GenreId]) REFERENCES [Genre] ([Id])
	
);
GO

CREATE TABLE [MusicPlaylist]
( 
    [MusicId] INT NOT NULL,
    [PlaylistId] INT NOT NULL,  
    CONSTRAINT [PK_MusicPlaylist] PRIMARY KEY ([MusicId], [PlaylistId]),
    CONSTRAINT [FK_Music] FOREIGN KEY ([MusicId]) REFERENCES [Music] ([Id]),
    CONSTRAINT [FK_Playlist] FOREIGN KEY ([PlaylistId]) REFERENCES [Playlist] ([Id])
);
GO